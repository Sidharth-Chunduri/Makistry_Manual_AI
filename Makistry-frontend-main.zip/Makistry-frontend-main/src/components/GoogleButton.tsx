// src/components/GoogleButton.tsx
import { Button } from "@/components/ui/button";
import { FcGoogle } from "react-icons/fc";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { auth } from "@/firebase";
import { exchangeIdToken } from "@/lib/firebaseAuth";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";

interface Props {
  className?: string;
  /* optional callback: pendingQuery replay, custom route, etc. */
  onSuccess?: () => void;
}

export function GoogleButton({ className, onSuccess }: Props) {
  const { login } = useAuth();
  const nav = useNavigate();

  const handle = async () => {
    const { user } = await signInWithPopup(auth, new GoogleAuthProvider());
    const jwt = await exchangeIdToken(await user.getIdToken());

    login(jwt);

    // If parent gave us something to do, run it; else go home.
    if (onSuccess) onSuccess();
    else nav("/");
  };

  return (
    <Button
      onClick={handle}
      variant="outline"
      className={`w-full flex items-center justify-center gap-2 ${className ?? ""}`}
    >
      <FcGoogle className="h-5 w-5" />
      Continue with Google
    </Button>
  );
}
